import React from 'react';
import logo from './logo.svg';
import './App.css';
import view from './components/View.js';
import addBook from './components/Add.js';
import contact from './components/Contact.js';
import BookCard from './components/BookCard';
import signUp from './components/signUp';
import login from './components/login';
import "bootstrap/dist/css/bootstrap.css";
// import Redirect from "../../node_modules/react-router-dom/Redirect";
import { BrowserRouter as Router, Route, Link, render,Redirect} from 'react-router-dom';

class App extends React.Component{
  render(){
    return(
      <Router>
        <React.Fragment>
            <nav className="navbar bg-dark">
              <div className="container-fluid" >
                <div style={{"justifyContent":"left"}}>
                  <Link className="navbar-header">Learning Portal</Link>    '
                  <Link to={'/view'}> View All Books </Link>'    '
                  <Link to={'/addbook'}> Add Books </Link>'   '
                  <Link to={'/contact'}> Contact </Link>
                </div>
                <div style={{"justifyContent":"right"}}>
                  {/* <div>{this.state.name}</div> */}
                  <Link to={'/signUp'}> SignUp </Link>
                  <Link to={'/login'}> login </Link>
                </div>
              </div>
            </nav>
            <div>
                <Route exact path="/view" component={view}/>
                <Route path="/addbook" component={addBook}/>
                <Route path="/contact" component={contact}/>
                <Route path="/signUp" component={signUp}/>
                <Route path="/login" component={login}/>
                <Route exact path="/" render={() => (<Redirect to="/view" />)} />  
                {/* <this will redirect the path of "/" to "/home"> */}

            </div>
        </React.Fragment>
      </Router>
    )
  }
}

export default App;

