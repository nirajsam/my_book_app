import React from 'react';
import axios from 'axios';

class signUp extends React.Component{
    constructor(){
        super();
        this.state={
            username:'',
            EmailId:'',
            password:'',
            rePassword:'',
            formErrors:{
                usernameErr:'',
                EmailIdErr:'',
                passwordErr:'',
                rePasswordErr:''
            },
            formValidity:{
                username:false,
                EmailId:false,
                password:false,
                rePassword:false,
            },
            registerForm:{
                username:'',
                EmailId:'',
                password:'',
            },
            formValid:false,
            successsMessage:''
        }
    }
    handleChange=(event)=>{
        var name=event.target.value
    }
    validateuserName=(e)=>{
        var userName=e.target.value;
        var formErrors=this.state.formErrors;
        var formValidity=this.state.formValidity;
        this.setState({username:e.target.value});
        if (userName.length<4 || (!userName.match(/^[A-z]+([ ][A-z]+)*$/))){
            formErrors.usernameErr="Name must be atleast 4 characters";
            formValidity.username=false
        }else{
            formErrors.usernameErr="";
            formValidity.username=true;
        }
        this.setState({formValidity:formValidity})
        this.setState({formValid:formValidity.userName && formValidity.username && 
            formValidity.password && formValidity.rePassword})
    }
    validateEmailId=(e)=>{
        const EmailId=e.target.value;
        var formErrors=this.state.formErrors;
        var formValidity=this.state.formValidity;
        this.setState({EmailId:e.target.value});
        if (EmailId.length<4 || (!EmailId.match(/^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$/))){
            formErrors.EmailIdErr="Incorrect email id";
            formValidity.EmailId=false
        }else{
            formErrors.EmailIdErr="";
            formValidity.EmailId=true;
        }
        this.setState({formValidity:formValidity})
        this.setState({formValid:formValidity.EmailId && formValidity.EmailId && 
            formValidity.password && formValidity.rePassword})
    }
    validatePassword=(e)=>{
        const Password=e.target.value;
        var formErrors=this.state.formErrors;
        var formValidity=this.state.formValidity;
        this.setState({password:e.target.value});
        if (Password.length<5 || (!Password.match(/^.*(?=.{8,})(?=.*[a-zA-Z])(?=.*\d)(?=.*[!#$%&? "]).*$/))){
            formErrors.passwordErr="please type some strong password";
            formValidity.password=false
        }else{
            formErrors.passwordErr="";
            formValidity.password=true;
        }
        this.setState({formValidity:formValidity})
        this.setState({formValid:formValidity.EmailId && formValidity.EmailId && 
            formValidity.password && formValidity.rePassword})
    }
    validateRePassword=(e)=>{
        var p1=e.target.value;
        console.log(p1)
        console.log(this.state.password)
        var formErrors=this.state.formErrors;
        var formValidity=this.state.formValidity;
        if(p1!==this.state.password){
            formErrors.rePasswordErr="password does not match";
        }else{
            formErrors.rePasswordErr="";
            formValidity.rePassword=true;
        }
        this.setState({formValidity:formValidity})
        this.setState({formValid:formValidity.EmailId && formValidity.EmailId && 
            formValidity.password && formValidity.rePassword})
    }
    registerUser = (event) => {
        this.state.registerForm.username=this.state.username
        this.state.registerForm.EmailId=this.state.EmailId
        this.state.registerForm.password=this.state.password
        console.log(this.state.registerForm)
        event.preventDefault(); 
        axios.post("http://localhost:1000/Posts",(this.state.registerForm))
            .then((response) => {
                this.setState({ successMessage: `User Registered Successfuly with id ${response.data.id}` })
                // console.log("success response", response);
            }).catch((error) => {
                // if server is running error will have a response
                if (error.response) {
                    console.log(error.response)
                    // error.response.data.message
                    this.setState({ errorMessage: `Data was not found` })
                } else {
                    // res.json({"message":err.message})
                    this.setState({ errorMessage: error.message })
                }
                // not running ==> server will not send send a response
                // console.log("error response", error);
            })
        }
    
    render(){
        return(
            <div style={{width:500, margin:'0px auto'}}>
                <h3 className="text-center">sign up here</h3>
                <form>
                    <div className="form-group">
                        <label>userName:</label>
                        <input type="text" className="form-control" onChange={this.validateuserName}></input>
                    </div>
                    <span className="text-danger">{this.state.formErrors.usernameErr}</span>
                    <div className="form-group">
                        <label>EmailId:</label>
                        <input type="text" className="form-control" onChange={this.validateEmailId}></input>
                    </div>
                    <span className="text-danger">{this.state.formErrors.EmailIdErr} </span>
                    <div className="form-group">
                        <label>Password:</label>
                        <input type="text" className="form-control" onChange={this.validatePassword}></input>
                    </div>
                    <span className="text-danger">{this.state.formErrors.passwordErr} </span>
                    <div className="form-group">
                        <label>Re-password:</label>
                        <input type="text" className="form-control" onChange={this.validateRePassword}></input>
                    </div>
                    <span className="text-danger">{this.state.formErrors.rePasswordErr} </span>
                    <button className="btn btn-success" onClick={this.registerUser} disabled={!this.state.formValid}>signup</button>
                </form>
            </div>
        )
    }
}
export default signUp;