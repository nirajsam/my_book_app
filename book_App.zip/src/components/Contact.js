import React from 'react';

class contact extends React.Component{
    render(){
        return(
            <h3>this is our contact</h3>
        )
    }
}
export default contact;