import React from "react";
import Redirect from "react-router-dom";
class BookCard extends React.Component {
  constructor() {
    super();
    this.state = {
      summary: null,
      counter:0
    };
  }
  incCount=()=>{
      this.setState({counter:this.state.counter+1})
      console.log(this.state.counter)
      if (this.state.counter%2==0){
        this.setState({ summary: this.props.book.summary });
      }else{
          this.setState({summary:""})
      }
  }
  render() {
    var note = null;

    return (
        <div style={{"padding":"2%"}}>
      <div className="card" style={{ width: 200 }}>
        <div className="card-body">
          <h5 className="card-title text-center">{this.props.book.title}</h5>
          <p className="card-text">
            <span>Author: {this.props.book.author}</span>
            <br />
            <span>Genre: {this.props.book.genre}</span> {note}
            <br />
          </p>
          <p>
            <i>{this.state.summary}</i>
          </p>
          <button
            className="btn btn-success"
            onClick={this.incCount}
          >
            View
          </button>
        </div>
      </div>
      </div>
    );
  }
}
export default BookCard;
