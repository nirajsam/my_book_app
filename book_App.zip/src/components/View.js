import React  from 'react';
import axios from 'axios';
import BookCard from './BookCard'

class view extends React.Component{
    constructor(props){
        super(props);
        this.state={
            result:""
        };
        this.fetchBooks=this.fetchBooks.bind(this)
    }
    componentDidMount(){
        this.fetchBooks();
    }
    fetchBooks(){
        axios.get("http://localhost:2000/books")
        .then((response)=>{
            this.setState({result:response.data})
        })
        console.log(this.state.result)
    }
    
    render(){
        const {r}=this.state.result;
        console.log(r)
        return(
            <div>
                <h3 className="text-center">Book Data</h3>
                <div className="row" style={{"justifyContent":"center"}}>
                {this.state.result
                ? this.state.result.map(book => <BookCard key={book.Id} book={book} />)
                : null}
                {this.state.errorMessage ? (
                <h4 className="text-danger">{this.state.errorMessage}</h4>
                ) : null}
                </div>
            </div>
        )
    }
}
export default view;