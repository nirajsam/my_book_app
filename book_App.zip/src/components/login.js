import React from 'react';
import axios from 'axios';
import signUp from './signUp.js'
import view from './View.js'
import AddBook from './Add.js'
import ReactDOM from "react-dom";
import {BrowserRouter as Router, link} from 'react-router-dom'

class login extends React.Component{
    constructor(){
        super();
        this.state={
            EmailId:'',
            password:'',

            loginValid:'false',
            success:'',
            result:'',
            errorMessage:'',
            id:1,
            name:''
        }
    }

    fetchUserData = (event) => {
        event.preventDefault()
        axios.get("http://localhost:1000/Posts/")
            .then((response) => {
                console.log(JSON.stringify(response.data))
                this.setState({ result:(response.data) })
                this.state.result.map(emp => {if(emp.EmailId==this.state.EmailId && emp.password===this.state.password){
                    this.setState({success:"login successful"});
                    this.setState({loginValid:'true'})
                    this.setState({name:emp.username})
                    ReactDOM.render(<AddBook name={emp.username}/>)
                }else{
                    this.setState({success:"you are not registered! first register youself"})
                }})
                console.log(JSON.stringify(this.state.result))
            }).catch((error) => {
                if (error.response) {
                    console.log(error.response)
                    this.setState({ errorMessage: "id not found" })
                } else {
                    // 
                    this.setState({ errorMessage: "id not found" })
                }

            })
    }
    emailChange = (event) => {

        let email=event.target.value;
        this.setState({EmailId:email})
    }
    passwordChange = (event) => {

        let password=event.target.value;
        this.setState({password:password})
    }
    render(){
        return(
            <div style={{width:500, margin:'0px auto'}}>
                <h3 className="text-center">login users</h3>
                <form action="http://localhost:3000/"> 
                    <div className="form-group">
                        <label>EmailId:</label>
                        <input type="text" className="form-control" onChange={this.emailChange}></input>
                    </div>
                    
                    <div className="form-group">
                        <label>Password:</label>
                        <input type="text" className="form-control" onChange={this.passwordChange}></input>
                    </div>
                    <span className="text-danger"></span>
                    {this.fetchUserData}
                    
                    <button className="btn btn-success"  disabled={!this.state.loginValid} 
                    onClick={this.fetchUserData}>
                        Login</button><br/>
                    <span className="text-danger">{this.state.success}</span><br/>
                    {!this.state.loginValid? <AddBook name={this.state.name}/>:<div>sam</div>}
                    <button className="btn btn-outline-primary" ><a href="http://localhost:3000/signUp">register</a></button>
                    
                </form>
            </div>
        )
    }
}
export default login;
