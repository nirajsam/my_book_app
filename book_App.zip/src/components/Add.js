import React from 'react'
import axios from 'axios'
class AddBook extends React.Component{
    constructor(props){
        super(props);
        this.state={
            title:'',
            author:'',
            genre:'',
            summary:'',
            formErrors:{
                titleErr:'',
                authorErr:'',
            },
            fieldValidity:{
                title:false,
                author:false
            },
            formValid:false,
            successMessage:'',
            errorMessage:'',
            userData:'',
            id:'',
            fetchData:''
        }
    }
    searchName=(e)=>{
        let sn=e.target.value;
        this.setState({id:sn})
    }
    registerUser = (event) => {
        console.log(this.state.successMessage);
        event.preventDefault(); 
        axios.post("http://localhost:2000/books",JSON.parse(this.state.userData))
            .then(function (response) {
                console.log(response);
            })
            .catch(function (error) {
                console.log(error);
            });
        }

    fetchUserData = () => {
        axios.get("http://localhost:2000/books/"+this.state.id)
            .then((response) => {
                this.setState({ fetchData:JSON.stringify(response.data) })
            }).catch((error) => {
                if (error.response) {
                    console.log(error.response)
                    this.setState({ errorMessage: this.state.title })
                } else {
                    // 
                    this.setState({ errorMessage: error.message })
                }

            })
    }
    
    validateTitle=(e)=>{
        const title=e.target.value;
        var formErrors=this.state.formErrors;
        var fieldValidity=this.state.fieldValidity;
        this.setState({title:e.target.value});
        if (title.length<4 || (!title.match(/^[A-z]+([ ][A-z]+)*$/))){
            formErrors.titleErr="Name must be atleast 4 characters";
            fieldValidity.title=false
        }else{
            formErrors.titleErr="";
            fieldValidity.title=true;
        }
        this.setState({fieldValidity:fieldValidity})
        this.setState({formValid:fieldValidity.title && fieldValidity.author})
    }
    validateauthor=(e)=>{
        const author=e.target.value;
        var formErrors=this.state.formErrors;
        var fieldValidity=this.state.fieldValidity;
        this.setState({author:e.target.value});
        if (author.length<3 || (!author.match(/^[A-z]+([ ][A-z]+)*$/))){
            formErrors.authorErr="Name must be atleast 3 characters";
            fieldValidity.author=false
        }else{
            formErrors.authorErr="";
            fieldValidity.author=true;
        }
        this.setState({fieldValidity:fieldValidity})
        this.setState({formValid:fieldValidity.title && fieldValidity.author})
    }
    Update=(e)=>{
        e.preventDefault();
        if (this.state.formValid){
            var formJson={
                title:this.state.title,
                author:this.state.author,
                genre:this.state.genre,
                summary:this.state.summary
            }
            this.setState({successMessage:"successfully added  "+this.state.title})
            this.setState({userData:JSON.stringify(formJson)})
        }
        
    }
    setGenre=(e)=>{
        let genre=e.target.value;
        this.setState({genre:genre})
    }
    setSummary=(e)=>{
        let summary=e.target.value;
        this.setState({summary:summary})
    }
    
    render(){
        //console.log(this.state.userData)
        return(
            <div style={{ "width":"500px","margin":"0px auto"}}>
                search book by id : 
                <input value={this.state.id} onChange={this.searchName}></input><br/>
                <button onClick={this.fetchUserData} className="mt-3 btn btn-primary">Fetch Data</button>
                {this.state.fetchData}
                {this.state.errorMessage}
                <h3 className="text-center">Add a Book</h3>
                <form onSubmit={this.registerUser}>
                    <div className="form-group">
                        <label>Title:</label>
                        <input className="form-control" value={this.state.title} onChange={this.validateTitle}></input>
                    </div>
                    <span className="text-danger">{this.state.formErrors.titleErr}</span>
                    <div className="form-group">
                        <label>author:</label>
                        <input className="form-control" value={this.state.author} onChange={this.validateauthor}></input>
                    </div>
                    <span className="text-danger">{this.state.formErrors.authorErr}</span>
                    <div className="form-group">
                        <label>genre:</label>
                        <select className="form-control"  onChange={this.setGenre} value={this.state.genre} >
                            <option value="Fiction">--select--</option>
                            <option value="Mystery thriller">Mystery thriller</option>
                            <option value="Fiction">Fiction</option>
                            <option value="Non-Fiction">Non-Fiction</option>
                        </select>
                    </div>
                    <div className="form-group">
                        <label>Summary:</label>
                        <input className="form-control" value={this.state.summary} onChange={this.setSummary}></input>
                    </div>
                    <button type="button" className="btn btn-success" onClick={this.Update} disabled={!this.state.formValid}>Update</button>
                    <button type="submit" className="btn btn-success" disabled={!this.state.formValid}>Submit</button>
                    
                </form>
                <span className="text-success">{this.state.successMessage}</span>
            </div>
        )
    }
}
export default AddBook;